Template found on link:
https://stackoverflow.com/questions/1911516/how-to-make-cheat-sheets-in-latex
